# APEX TOUR – APK বিল্ড গাইড

## ফোল্ডারে কী আছে
| ফাইল | কাজ |
|---|---|
| `index.html` | পুরো অ্যাপের UI (আপনার APEX_TOUR_BD_CATEGORY_FIX.html + update fix) |
| `version.txt` | অ্যাপ ভার্সন। **প্রতিবার নতুন APK বানানোর আগে এটা বাড়াবেন** (1.0.0 → 1.0.1) |
| `logo_url.txt` | অ্যাপ লোগোর লিংক (বা repo তে `app_logo.png` / `app_logo.jpg` রাখলে সেটাই নিবে) |
| `native/` | Android native কোড (installer, signature guard, FileProvider) |
| `scripts/` | build/patch script |
| `.github/workflows/build-apk.yml` | GitHub এ APK বানানোর অটোমেশন |
| `android/app/google-services.json` | Firebase (push notification) config |

## প্রথমবার সেটআপ (একবারই)
1. GitHub এ আপনার repo তে এই ফোল্ডারের সব ফাইল আপলোড করুন (পুরোনো ফাইল মুছে)।
2. `GITHUB_SECRETS_PRIVATE.txt` ফাইল দেখে repo তে ৪টা Secret বানান: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
   (Settings → Secrets and variables → Actions → New repository secret)।
3. Actions ট্যাব → "Build APEX TOUR APK" → Run workflow।
4. শেষ হলে নিচে Artifacts থেকে `APEX-TOUR-APK-v1.0.0` ডাউনলোড (zip খুললে APK)।
5. ফোনে আগের অ্যাপ (AR/পুরোনো) **uninstall** করে এই APK install করুন (একবারই, কারণ key বদলেছে)।

## প্রতিবার নতুন আপডেট দিতে
1. `index.html` এ যা বদলানোর বদলান।
2. `version.txt` এ ভার্সন বাড়ান (যেমন `1.0.1`)।
3. GitHub এ commit → অটো build হবে (বা Run workflow)।
4. APK ডাউনলোড করে Admin প্যানেল → App Update → APK upload।
   **New Version** ঘরে লিখুন `v1.0.1` (version.txt এর সাথে হুবহু মিল, সামনে v)। Update Popup ON করে Save।
5. পুরোনো ভার্সনের ইউজাররা অ্যাপ খুললে Update স্ক্রিন পাবে → Download → Install Now।
   প্রথমবার "Install unknown apps" permission চাইবে, দিয়ে ফিরে এসে আবার Install Now চাপবে।

## ⚠️ জরুরি
- `apex-release.jks` (keystore) কখনো হারাবেন না, কাউকে দিবেন না, GitHub এ আপলোড করবেন না। হারালে আর আপডেট দেওয়া যাবে না।
- package name `com.artourbd.app` রাখা হয়েছে, কারণ `google-services.json` ওই নামে বানানো। বদলাতে চাইলে Firebase এ নতুন Android app বানিয়ে নতুন google-services.json লাগবে।
- Obfuscation বন্ধ করতে চাইলে workflow এর "Build web app" স্টেপে `env: OBFUSCATE: '0'` দিন।
