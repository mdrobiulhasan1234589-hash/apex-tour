package com.artourbd.app;

import androidx.core.content.FileProvider;

/** Own FileProvider subclass (avoids a clash with Capacitor's FileProvider). */
public class ApkFileProvider extends FileProvider {
}
