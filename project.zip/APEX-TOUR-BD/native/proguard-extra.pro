# ---- APEX TOUR extra R8 / ProGuard rules (appended to app/proguard-rules.pro) ----
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# JS bridges must keep their method names (called from the WebView by name)
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.artourbd.app.ApkInstaller { *; }
-keep class com.artourbd.app.ApkFileProvider { *; }
-keep class com.artourbd.app.MainActivity { *; }
-keep class com.artourbd.app.MainActivity$AndroidFCMBridge { *; }

# Capacitor
-keep class com.getcapacitor.** { *; }
-dontwarn com.getcapacitor.**

# Remove debug logging from the release build
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}
