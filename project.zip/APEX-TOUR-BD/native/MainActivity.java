package com.artourbd.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.BridgeActivity;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends BridgeActivity {

    private static final String TAG = "AR-TOUR-FCM";
    private static final String PREFS = "art_fcm_prefs";
    private static final String TOKEN_KEY = "fcm_token";

    private long lastBackPress = 0;
    private final long EXIT_INTERVAL = 2000;

    // Filled automatically by the GitHub workflow with the SHA-256 of YOUR release key.
    // If someone re-signs a modified copy of the app (MT Manager etc.) the hash will not
    // match and the app closes itself.
    private static final String EXPECTED_CERT_SHA256 = "__CERT_SHA256__";

    /** SHA-256 (lowercase hex) of the certificate this app is currently signed with. */
    @SuppressWarnings("deprecation")
    static String currentCertSha256(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo pi = pm.getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo si = pi.signingInfo;
                if (si == null) return null;
                sigs = si.getApkContentsSigners();
            } else {
                PackageInfo pi = pm.getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNATURES);
                sigs = pi.signatures;
            }
            if (sigs == null || sigs.length == 0) return null;
            return ApkInstaller.sha256Hex(sigs[0].toByteArray());
        } catch (Exception e) {
            return null;
        }
    }

    private boolean signatureIsValid() {
        if (EXPECTED_CERT_SHA256.startsWith("__")) return true; // local/dev build, guard not armed
        String cur = currentCertSha256(this);
        return cur != null && cur.equalsIgnoreCase(EXPECTED_CERT_SHA256);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!signatureIsValid()) {
            Toast.makeText(this, "This copy of the app was modified. Please install the official app.", Toast.LENGTH_LONG).show();
            finishAndRemoveTask();
            return;
        }

        WebView.setWebContentsDebuggingEnabled(false);

        configureSystemBars();
        configureWebView();
        requestNotificationPermission();

        WebView webView = getBridge().getWebView();
        if (webView != null) {
            webView.addJavascriptInterface(new AndroidFCMBridge(), "AndroidFCM");
            webView.addJavascriptInterface(new ApkInstaller(this, webView), "AndroidInstaller");
            Log.d(TAG, "AndroidFCM bridge added");
        }

        fetchAndCacheFcmToken();
    }

    private void configureSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.BLACK);
        window.setNavigationBarColor(Color.BLACK);

        // 0 = light-status-bar flag OFF, so time/network/battery stay white.
        window.getDecorView().setSystemUiVisibility(0);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
            window.setNavigationBarDividerColor(Color.BLACK);
        }
    }

    private void configureWebView() {
        WebView webView = getBridge().getWebView();
        if (webView == null) return;

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setTextZoom(100);

        // Keep rendering on the GPU; do not force software rendering.
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setBackgroundColor(Color.BLACK);
    }

    private void fetchAndCacheFcmToken() {
        try {
            FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Log.e(TAG, "FCM token fetch failed", task.getException());
                        return;
                    }
                    String token = task.getResult();
                    if (token != null && !token.isEmpty()) {
                        getSharedPreferences(PREFS, MODE_PRIVATE)
                            .edit()
                            .putString(TOKEN_KEY, token)
                            .apply();
                        Log.d(TAG, "FCM token cached");

                        WebView wv = getBridge().getWebView();
                        if (wv != null) {
                            wv.post(() -> wv.evaluateJavascript(
                                "javascript:if(window.saveDeviceFcmToken)saveDeviceFcmToken();",
                                null
                            ));
                        }
                    }
                });
        } catch (Exception e) {
            Log.e(TAG, "FCM init error", e);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {
                new Handler().postDelayed(() -> {
                    ActivityCompat.requestPermissions(
                            this,
                            new String[]{Manifest.permission.POST_NOTIFICATIONS},
                            1001
                    );
                }, 1200);
            }
        }
    }

    @Override
    public void onBackPressed() {
        WebView webView = getBridge().getWebView();
        if (webView == null) {
            exitApp();
            return;
        }
        String checkPage =
                "(document.body && document.body.classList.contains('sub-page')) ? 'SUB' : 'MAIN'";
        webView.evaluateJavascript(checkPage, value -> {
            boolean isSubPage = value != null && value.contains("SUB");
            if (isSubPage) {
                webView.evaluateJavascript("history.back();", null);
                return;
            }
            long now = System.currentTimeMillis();
            if (now - lastBackPress < EXIT_INTERVAL) {
                exitApp();
            } else {
                lastBackPress = now;
                Toast.makeText(MainActivity.this,
                        "Press back again to exit",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void exitApp() {
        finishAndRemoveTask();
    }

    public class AndroidFCMBridge {

        @JavascriptInterface
        public String getToken() {
            String cached = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(TOKEN_KEY, "");
            if (cached != null && !cached.isEmpty()) {
                return cached;
            }
            try {
                FirebaseMessaging.getInstance().getToken()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            String t = task.getResult();
                            if (t != null && !t.isEmpty()) {
                                getSharedPreferences(PREFS, MODE_PRIVATE)
                                    .edit()
                                    .putString(TOKEN_KEY, t)
                                    .apply();
                            }
                        }
                    });
            } catch (Exception e) {
                Log.e(TAG, "Bridge token error", e);
            }
            return "";
        }

        @JavascriptInterface
        public String getPlatform() {
            return "android";
        }
    }
}
