package com.artourbd.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * Downloads the update APK and opens the Android system installer.
 * JS side:  window.AndroidInstaller.downloadApk(url, fileName)
 *           window.AndroidInstaller.installApk()
 *           window.AndroidInstaller.cancelDownload()
 * Native -> JS callbacks: window.onApkProgress(received,total),
 *           window.onApkDownloaded(), window.onApkError(message)
 *
 * Safety: only https, the downloaded file must be a real APK of THIS app
 * (same package name AND same signing certificate), otherwise it is deleted.
 */
public class ApkInstaller {

    private final Activity act;
    private final WebView web;
    private volatile boolean cancelled = false;
    private volatile boolean downloading = false;
    private volatile File apkFile = null;

    public ApkInstaller(Activity activity, WebView webView) {
        this.act = activity;
        this.web = webView;
    }

    private void js(final String code) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    web.evaluateJavascript(code, null);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void fail(String message) {
        String safe = message.replace("\\", " ").replace("'", " ");
        js("window.onApkError && window.onApkError('" + safe + "')");
    }

    @JavascriptInterface
    public void downloadApk(final String url, final String fileName) {
        if (downloading) return;
        if (url == null || !url.startsWith("https://")) {
            fail("Invalid download link");
            return;
        }
        final String safeName = (fileName == null ? "update.apk" : fileName)
                .replaceAll("[^A-Za-z0-9._-]", "_");
        cancelled = false;
        downloading = true;
        apkFile = null;

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                File part = null;
                try {
                    File dir = new File(act.getCacheDir(), "apk");
                    if (!dir.exists()) dir.mkdirs();
                    File[] old = dir.listFiles();
                    if (old != null) for (File f : old) f.delete();

                    part = new File(dir, safeName + ".part");
                    File finalFile = new File(dir, safeName.endsWith(".apk") ? safeName : safeName + ".apk");

                    conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setConnectTimeout(20000);
                    conn.setReadTimeout(30000);
                    conn.setInstanceFollowRedirects(true);
                    int code = conn.getResponseCode();
                    if (code != 200) {
                        fail("Server error " + code);
                        return;
                    }
                    long total = conn.getContentLengthLong();
                    long got = 0;
                    long lastEmit = 0;

                    InputStream in = conn.getInputStream();
                    OutputStream out = new FileOutputStream(part);
                    byte[] buf = new byte[32768];
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        if (cancelled) {
                            out.close();
                            in.close();
                            part.delete();
                            return;
                        }
                        out.write(buf, 0, n);
                        got += n;
                        long now = System.currentTimeMillis();
                        if (now - lastEmit > 200) {
                            lastEmit = now;
                            js("window.onApkProgress && window.onApkProgress(" + got + "," + total + ")");
                        }
                    }
                    out.flush();
                    out.close();
                    in.close();

                    if (got < 100 * 1024) {
                        part.delete();
                        fail("Downloaded file is too small");
                        return;
                    }
                    // ZIP magic "PK"
                    FileInputStream fis = new FileInputStream(part);
                    int b1 = fis.read();
                    int b2 = fis.read();
                    fis.close();
                    if (b1 != 0x50 || b2 != 0x4B) {
                        part.delete();
                        fail("Downloaded file is not an APK");
                        return;
                    }

                    if (finalFile.exists()) finalFile.delete();
                    if (!part.renameTo(finalFile)) {
                        fail("Could not save the file");
                        return;
                    }

                    String problem = verifyApk(finalFile);
                    if (problem != null) {
                        finalFile.delete();
                        fail(problem);
                        return;
                    }

                    apkFile = finalFile;
                    js("window.onApkProgress && window.onApkProgress(" + got + "," + got + ")");
                    js("window.onApkDownloaded && window.onApkDownloaded()");
                } catch (Exception e) {
                    if (part != null) part.delete();
                    fail("Download failed. Check your internet.");
                } finally {
                    downloading = false;
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }

    /** Returns null when OK, otherwise an error message. */
    @SuppressWarnings("deprecation")
    private String verifyApk(File f) {
        try {
            PackageManager pm = act.getPackageManager();
            int flags = Build.VERSION.SDK_INT >= 28
                    ? PackageManager.GET_SIGNING_CERTIFICATES
                    : PackageManager.GET_SIGNATURES;
            PackageInfo info = pm.getPackageArchiveInfo(f.getAbsolutePath(), flags);
            if (info == null) return "Corrupted APK file";
            if (!act.getPackageName().equals(info.packageName)) return "Wrong app package";

            Signature[] theirs = null;
            if (Build.VERSION.SDK_INT >= 28) {
                if (info.signingInfo != null) theirs = info.signingInfo.getApkContentsSigners();
            } else {
                theirs = info.signatures;
            }
            if (theirs == null || theirs.length == 0) return null; // cannot read -> Android installer will still enforce signature

            String mine = MainActivity.currentCertSha256(act);
            if (mine == null) return null;
            for (Signature s : theirs) {
                if (mine.equals(sha256Hex(s.toByteArray()))) return null;
            }
            return "APK signature does not match";
        } catch (Exception e) {
            return null;
        }
    }

    static String sha256Hex(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] d = md.digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte x : d) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    @JavascriptInterface
    public void cancelDownload() {
        cancelled = true;
    }

    @JavascriptInterface
    public void installApk() {
        final File f = apkFile;
        if (f == null || !f.exists()) {
            fail("Update file not found. Download again.");
            return;
        }
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (Build.VERSION.SDK_INT >= 26 && !act.getPackageManager().canRequestPackageInstalls()) {
                        Toast.makeText(act,
                                "ইনস্টল অনুমতি দিন, তারপর ফিরে এসে আবার Install Now চাপুন",
                                Toast.LENGTH_LONG).show();
                        Intent s = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + act.getPackageName()));
                        s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        act.startActivity(s);
                        return;
                    }
                    Uri uri = FileProvider.getUriForFile(act, act.getPackageName() + ".apkprovider", f);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(uri, "application/vnd.android.package-archive");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                } catch (Exception e) {
                    fail("Could not open the installer");
                }
            }
        });
    }
}
