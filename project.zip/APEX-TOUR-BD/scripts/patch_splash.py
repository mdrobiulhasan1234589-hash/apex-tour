from pathlib import Path
import re

res = Path("android/app/src/main/res")
touched = 0

# Capacitor's generated launch theme is patched here only.
# index.html and its own splash are completely untouched.
for path in res.rglob("*.xml"):
    text = path.read_text()
    original = text

    if "AppTheme.NoActionBarLaunch" in text:
        # Do not let the native/compat splash theme hold the app.
        text = re.sub(
            r'(<style\s+name="AppTheme\.NoActionBarLaunch"\s+parent=")Theme\.SplashScreen("[^>]*>)',
            r'\1AppTheme.NoActionBar\2',
            text,
        )

        # If the generated theme still contains a splash drawable,
        # replace it with a transparent 1dp drawable.
        text = text.replace(
            '@drawable/splash',
            '@drawable/transparent_splash_icon'
        )
        text = text.replace(
            '@mipmap/ic_launcher',
            '@drawable/transparent_splash_icon'
        )

        if text != original:
            path.write_text(text)
            touched += 1
            print(f"Patched native launch theme: {path}")

print(f"Native launch splash patch complete. XML files changed: {touched}")
print("index.html was NOT modified.")
