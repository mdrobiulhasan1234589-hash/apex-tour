"""Adds Firebase Messaging dependency + google-services plugin to the generated Android project."""
from pathlib import Path

# ---- app/build.gradle: dependency ----
app = Path("android/app/build.gradle")
text = app.read_text(encoding="utf-8")

if "firebase-messaging" not in text:
    start = text.find("dependencies {")
    if start == -1:
        raise SystemExit("ERROR: dependencies block missing")
    depth, end = 0, -1
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                end = i
                break
    if end == -1:
        raise SystemExit("ERROR: closing brace missing")
    line = "\n    // Firebase Cloud Messaging\n    implementation 'com.google.firebase:firebase-messaging:23.4.0'\n"
    text = text[:end] + line + text[end:]
    print("OK: firebase-messaging added")

# ---- apply plugin ----
if "com.google.gms.google-services" not in text:
    text = 'apply plugin: "com.google.gms.google-services"\n' + text
    print("OK: google-services plugin applied")
app.write_text(text, encoding="utf-8")

# ---- root build.gradle: classpath ----
root = Path("android/build.gradle")
r = root.read_text(encoding="utf-8")
if "com.google.gms:google-services" not in r:
    bs = r.find("buildscript")
    if bs == -1:
        r = ('buildscript {\n    repositories {\n        google()\n        mavenCentral()\n    }\n'
             '    dependencies {\n        classpath "com.google.gms:google-services:4.4.0"\n    }\n}\n\n') + r
    else:
        dep = r.find("dependencies", bs)
        brace = r.find("{", dep)
        r = r[:brace + 1] + '\n        classpath "com.google.gms:google-services:4.4.0"' + r[brace + 1:]
    root.write_text(r, encoding="utf-8")
    print("OK: classpath added")
print(root.read_text(encoding="utf-8")[:900])
