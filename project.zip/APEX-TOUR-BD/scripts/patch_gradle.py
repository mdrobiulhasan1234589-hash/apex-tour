"""Appends release-signing, versioning, R8 minify and hardening to android/app/build.gradle."""
from pathlib import Path

p = Path("android/app/build.gradle")
t = p.read_text(encoding="utf-8")

block = '''

// ===== APEX TOUR: added by scripts/patch_gradle.py =====
android {
    defaultConfig {
        versionCode Integer.parseInt(System.getenv("VERSION_CODE"))
        versionName System.getenv("APP_VERSION")
    }
    signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_FILE"))
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            debuggable false
            proguardFiles getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"
        }
    }
    lint {
        checkReleaseBuilds false
        abortOnError false
    }
}
'''
if "APEX TOUR: added by scripts/patch_gradle.py" not in t:
    t += block
p.write_text(t, encoding="utf-8")
print("build.gradle patched")
