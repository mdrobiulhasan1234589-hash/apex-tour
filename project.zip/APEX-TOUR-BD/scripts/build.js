/*
 * APEX TOUR - web build script
 *  1. reads version.txt  -> injects window.ART_APP_VERSION = 'vX.Y.Z' into index.html
 *  2. fixes the logo path for Android
 *  3. obfuscates every inline <script> (set OBFUSCATE=0 to turn off)
 *  4. writes dist/index.html + dist/tla_tour_logo.png
 * If obfuscation of any script fails or produces invalid JS, the ORIGINAL script is kept
 * (the build never breaks the app because of obfuscation).
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');

const root = path.join(__dirname, '..');
const dist = path.join(root, 'dist');

const version = fs.readFileSync(path.join(root, 'version.txt'), 'utf8').trim();
if (!/^\d+\.\d+\.\d+$/.test(version)) {
  console.error('version.txt must look like 1.0.0 (got: ' + version + ')');
  process.exit(1);
}

let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

// 1. version
const verRe = /window\.ART_APP_VERSION\s*=\s*'[^']*'/;
if (!verRe.test(html)) {
  console.error('ART_APP_VERSION line not found in index.html');
  process.exit(1);
}
html = html.replace(verRe, "window.ART_APP_VERSION = 'v" + version + "'");

// 2. logo path
html = html.split('file:///android_asset/tla_tour_logo.png').join('./tla_tour_logo.png');

// 3. obfuscation
let obf = null;
if (process.env.OBFUSCATE !== '0') {
  try { obf = require('javascript-obfuscator'); }
  catch (e) { console.warn('javascript-obfuscator not installed - skipping obfuscation'); }
}

function syntaxOk(code, isModule) {
  const f = path.join(os.tmpdir(), 'chk_' + Date.now() + '_' + Math.random().toString(36).slice(2) + (isModule ? '.mjs' : '.js'));
  fs.writeFileSync(f, code);
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); return true; }
  catch (e) { return false; }
  finally { try { fs.unlinkSync(f); } catch (e) {} }
}

let done = 0, kept = 0, before = 0, after = 0;
if (obf) {
  html = html.replace(/<script(\s[^>]*)?>([\s\S]*?)<\/script>/gi, (full, attrs, code) => {
    attrs = attrs || '';
    if (/\bsrc\s*=/.test(attrs)) return full;                         // external script
    const typeM = attrs.match(/\btype\s*=\s*["']?([^"'\s>]+)/i);
    const type = typeM ? typeM[1].toLowerCase() : '';
    if (type && type !== 'module' && type !== 'text/javascript' && type !== 'application/javascript') return full; // json / templates
    if (code.trim().length < 80) return full;
    const isModule = type === 'module';
    before += code.length;
    try {
      let out = obf.obfuscate(code, {
        compact: true,
        simplify: true,
        renameGlobals: false,            // inline onclick="fn()" handlers need real global names
        renameProperties: false,
        identifierNamesGenerator: 'hexadecimal',
        stringArray: true,
        stringArrayEncoding: ['base64'],
        stringArrayThreshold: 0.75,
        rotateStringArray: true,
        shuffleStringArray: true,
        stringArrayWrappersCount: 1,
        splitStrings: false,
        controlFlowFlattening: false,    // slow + risky on a big app
        deadCodeInjection: false,
        selfDefending: false,
        debugProtection: false,
        disableConsoleOutput: false,
        transformObjectKeys: false,
        numbersToExpressions: false,
        unicodeEscapeSequence: false,
        target: 'browser',
        sourceType: isModule ? 'module' : 'script'
      }).getObfuscatedCode();
      out = out.replace(/<\/script/gi, '<\\/script');
      if (!syntaxOk(out, isModule)) throw new Error('obfuscated output failed syntax check');
      done++; after += out.length;
      return '<script' + attrs + '>' + out + '</script>';
    } catch (e) {
      kept++; after += code.length;
      console.warn('! script kept un-obfuscated: ' + String(e.message).slice(0, 120));
      return full;
    }
  });
  console.log('Obfuscation: ' + done + ' script(s) protected, ' + kept + ' kept as-is, ' + Math.round(before / 1024) + ' KB -> ' + Math.round(after / 1024) + ' KB');
}

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });
fs.writeFileSync(path.join(dist, 'index.html'), html);
fs.copyFileSync(path.join(root, 'tla_tour_logo.png'), path.join(dist, 'tla_tour_logo.png'));
console.log('Built dist/ for version v' + version);
