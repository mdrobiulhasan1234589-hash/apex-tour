"""Hardens + extends the generated AndroidManifest.xml (permissions, provider, FCM service)."""
from pathlib import Path

p = Path("android/app/src/main/AndroidManifest.xml")
t = p.read_text(encoding="utf-8")

perms = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.REQUEST_INSTALL_PACKAGES",   # needed to open the APK installer for in-app update
]
add = ""
for perm in perms:
    if perm not in t:
        add += '    <uses-permission android:name="%s" />\n' % perm
if add:
    t = t.replace("<application", add + "\n    <application", 1)

# --- hardening ---
t = t.replace('android:allowBackup="true"', 'android:allowBackup="false"')
if "android:allowBackup" not in t:
    t = t.replace("<application", '<application android:allowBackup="false"', 1)
if "usesCleartextTraffic" not in t:
    t = t.replace("<application", '<application android:usesCleartextTraffic="false"', 1)

extra = ""
if "ApkFileProvider" not in t:
    extra += '''
        <provider
            android:name="com.artourbd.app.ApkFileProvider"
            android:authorities="${applicationId}.apkprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/apk_paths" />
        </provider>
'''
if "FirebaseMessagingService" not in t:
    extra += '''
        <service
            android:name="com.google.firebase.messaging.FirebaseMessagingService"
            android:exported="false">
            <intent-filter>
                <action android:name="com.google.firebase.MESSAGING_EVENT" />
            </intent-filter>
        </service>

        <meta-data
            android:name="com.google.firebase.messaging.default_notification_channel_id"
            android:value="art_tour_default" />
'''
if extra:
    t = t.replace("</application>", extra + "\n    </application>")

p.write_text(t, encoding="utf-8")
print("Manifest patched")
print(t)
