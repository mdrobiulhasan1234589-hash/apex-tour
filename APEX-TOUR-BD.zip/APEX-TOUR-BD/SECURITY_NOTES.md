# APEX TOUR – Security notes

## What the APK build already protects (unchanged)
- Release signing with your own key, R8 minify + resource shrink, `debuggable false`
- `allowBackup=false`, no cleartext HTTP, WebView debugging off
- Signature guard (modified / re-signed copy closes itself)
- In-app update only from https and only if package + signing key match
- All inline JavaScript obfuscated at build time (`scripts/build.js`)

## Added in this version
1. **HTML escaping** (`window.escHtml` in index.html) for text typed by users that is shown
   inside other users' screens: player IGN, leaderboard username, TrxID, mobile number.
   Before this, a name like `<img src=x onerror=...>` could run code on other phones.
2. **WebView file access OFF** (`setAllowFileAccess(false)` + file-URL flags). The app is served from
   https://localhost, so nothing is lost.
3. Obfuscation slightly stronger (more strings hidden, numbers hidden, `console.*` removed).
   If a screen ever goes blank after a build, set `OBFUSCATE: '0'` in the workflow to compare.

## Things that must be checked in Supabase / Firebase (not in the APK)
The APK can always be unzipped, so the real lock is on the server:
- **RLS ON** for every table: profiles, deposit_requests, withdraw_requests, spin_history,
  support_tickets, fcm_tokens, match_participants, notifications, banned_devices.
- A user may read/write ONLY their own rows (`auth.uid() = user_id`).
- `spin_history` insert from the app: let the `spin_daily_wheel` RPC write it and remove the
  client INSERT policy (otherwise a user can fake history rows).
- Ban check (`profile.banned`) must also be enforced inside the RPCs / RLS, not only in index.html.
- `profiles` is read with `select('*')` – use a view / explicit columns if it has internal columns.
- Edge functions (secure-login, rapid-service, ff-uid-lookup, ai-support): verify the JWT and rate-limit.
- Server-side length/character validation for username, IGN and TrxID (the app now escapes them,
  but the server should still reject `<` `>` and very long values).
- Firebase Realtime DB / Storage rules: no public write; consider Firebase App Check.
- Never put `service_role` key, Telegram bot token or any API secret in index.html.
